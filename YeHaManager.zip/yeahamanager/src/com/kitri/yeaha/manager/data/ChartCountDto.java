package com.kitri.yeaha.manager.data;

public class ChartCountDto {
	
	private int cnt_01;
	private int cnt_02;
	private int cnt_03;
	private int cnt_04;
	private int cnt_05;
	private int cnt_06;
	private int cnt_07;
	private int cnt_08;
	private int cnt_09;
	private int cnt_10;
	private int cnt_11;
	private int cnt_12;
	private int cnt_13;
	public int getCnt_01() {
		return cnt_01;
	}
	public void setCnt_01(int cnt_01) {
		this.cnt_01 = cnt_01;
	}
	public int getCnt_02() {
		return cnt_02;
	}
	public void setCnt_02(int cnt_02) {
		this.cnt_02 = cnt_02;
	}
	public int getCnt_03() {
		return cnt_03;
	}
	public void setCnt_03(int cnt_03) {
		this.cnt_03 = cnt_03;
	}
	public int getCnt_04() {
		return cnt_04;
	}
	public void setCnt_04(int cnt_04) {
		this.cnt_04 = cnt_04;
	}
	public int getCnt_05() {
		return cnt_05;
	}
	public void setCnt_05(int cnt_05) {
		this.cnt_05 = cnt_05;
	}
	public int getCnt_06() {
		return cnt_06;
	}
	public void setCnt_06(int cnt_06) {
		this.cnt_06 = cnt_06;
	}
	public int getCnt_07() {
		return cnt_07;
	}
	public void setCnt_07(int cnt_07) {
		this.cnt_07 = cnt_07;
	}
	public int getCnt_08() {
		return cnt_08;
	}
	public void setCnt_08(int cnt_08) {
		this.cnt_08 = cnt_08;
	}
	public int getCnt_09() {
		return cnt_09;
	}
	public void setCnt_09(int cnt_09) {
		this.cnt_09 = cnt_09;
	}
	public int getCnt_10() {
		return cnt_10;
	}
	public void setCnt_10(int cnt_10) {
		this.cnt_10 = cnt_10;
	}
	public int getCnt_11() {
		return cnt_11;
	}
	public void setCnt_11(int cnt_11) {
		this.cnt_11 = cnt_11;
	}
	public int getCnt_12() {
		return cnt_12;
	}
	public void setCnt_12(int cnt_12) {
		this.cnt_12 = cnt_12;
	}
	public int getCnt_13() {
		return cnt_13;
	}
	public void setCnt_13(int cnt_13) {
		this.cnt_13 = cnt_13;
	}
	
	

}
