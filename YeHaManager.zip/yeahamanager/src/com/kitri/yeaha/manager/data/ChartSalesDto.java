package com.kitri.yeaha.manager.data;

public class ChartSalesDto {

	
	private int food_sales;
	private int ticket_sales;
	private int d_ticket_sales;
	
	
	public int getFood_sales() {
		return food_sales;
	}
	public void setFood_sales(int food_sales) {
		this.food_sales = food_sales;
	}
	public int getTicket_sales() {
		return ticket_sales;
	}
	public void setTicket_sales(int ticket_sales) {
		this.ticket_sales = ticket_sales;
	}
	public int getD_ticket_sales() {
		return d_ticket_sales;
	}
	public void setD_ticket_sales(int d_ticket_sales) {
		this.d_ticket_sales = d_ticket_sales;
	}
		
}
