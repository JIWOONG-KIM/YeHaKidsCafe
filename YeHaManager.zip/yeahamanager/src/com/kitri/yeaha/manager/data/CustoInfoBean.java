package com.kitri.yeaha.manager.data;

public class CustoInfoBean {
	private int customer_number;
	private String parents_name;
	private String kids_name;
	private String phone_number;

	public int getCustomer_number() {
		return customer_number;
	}

	public void setCustomer_number(int customer_number) {
		this.customer_number = customer_number;
	}

	public String getParents_name() {
		return parents_name;
	}

	public void setParents_name(String parents_name) {
		this.parents_name = parents_name;
	}

	public String getKids_name() {
		return kids_name;
	}

	public void setKids_name(String kids_name) {
		this.kids_name = kids_name;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

}
