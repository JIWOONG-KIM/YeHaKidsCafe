package com.kitri.yeaha.manager.data;

public class YeahhaBean {
	
	private int menu_id;
	private int categorys;
	private String menu_name;
	private int price;
	
	public int getMenu_id() {
		return menu_id;
	}
	public void setMenu_id(int menu_id) {
		this.menu_id = menu_id;
	}
	public int getCategorys() {
		return categorys;
	}
	public void setCategorys(int categorys) {
		this.categorys = categorys;
	}
	public String getMenu_name() {
		return menu_name;
	}
	public void setMenu_name(String menu_name) {
		this.menu_name = menu_name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
}
