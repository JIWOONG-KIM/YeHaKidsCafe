package com.kitri.yeaha.manager.data;

public class SalesAvgDto {

	private int avg_01;
	private int avg_02;
	private int avg_03;
	private String befMonth;
	
	
	public int getAvg_01() {
		return avg_01;
	}
	public void setAvg_01(int avg_01) {
		this.avg_01 = avg_01;
	}
	public int getAvg_02() {
		return avg_02;
	}
	public void setAvg_02(int avg_02) {
		this.avg_02 = avg_02;
	}
	public int getAvg_03() {
		return avg_03;
	}
	public void setAvg_03(int avg_03) {
		this.avg_03 = avg_03;
	}
	public String getBefMonth() {
		return befMonth;
	}
	public void setBefMonth(String befMonth) {
		this.befMonth = befMonth;
	}

	
}
