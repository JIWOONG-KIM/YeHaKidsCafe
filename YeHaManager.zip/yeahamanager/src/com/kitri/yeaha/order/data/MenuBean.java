package com.kitri.yeaha.order.data;



public class MenuBean {
	private String MENU_NAME;
	private String CATEGORYS;
	private int PRICE;
	
	public String getMENU_NAME() {
		return MENU_NAME;
	}
	public void setMENU_NAME(String mENU_NAME) {
		MENU_NAME = mENU_NAME;
	}
	public String getCATEGORYS() {
		return CATEGORYS;
	}
	public void setCATEGORYS(String cATEGORYS) {
		CATEGORYS = cATEGORYS;
	}
	public int getPRICE() {
		return PRICE;
	}
	public void setPRICE(int pRICE) {
		PRICE = pRICE;
	}

	
}
